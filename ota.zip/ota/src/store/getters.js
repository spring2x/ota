import Cookies from 'js-cookie';
const getters = {
  sidebar: state => state.app.sidebar,
  token: state =>state.user.token,
  name: state => state.user.user.name,
  userId: state => state.user.user.userId,
  roles: state =>state.user.roles,
  permission_routers: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  avatar:()=>"https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=951120017,198117664&fm=117&gp=0.jpg"
};
export default getters
