import { login, regist, logout, getInfo, getCode } from 'api/login';
import Cookies from 'js-cookie';
import { Message } from 'element-ui';
const user = {
    state: {
        user: "",
        token: Cookies.get("token"),
        roles: []
    },
    mutations: {
        SET_USER: (state, user) => {
            state.user = user;
        },
        SET_TOKEN: (state, user) => {
            state.token = user.token;
            Cookies.set("token", user.token);
            Cookies.set("user", JSON.stringify(user));
        },
        SET_ROLES: (state, roles) => {
            state.roles = roles;
        },
        LOGOUT_USER: state => {
            Cookies.remove('user');
            Cookies.remove('token');
            state.user = '';
        }
    },

    actions: {
        // 登录
        Login({ commit }, userInfo) {
            return new Promise((resolve, reject) => {
                login(userInfo).then(response => {
                    console.log(response)
                    const data = response.data;
                    if (data.code === "0000") {
                        const user = {
                            name: data.name,
                            token: data.token,
                            userId: data.userId
                        }
                        //设置用户信息
                        commit("SET_TOKEN", user);
                    }
                    resolve(data);
                }).catch(error => {
                    reject(error);
                });
            });
        },

        //获取用户信息
        GetInfo({ commit }) {
            return new Promise((resolve, reject) => {
                let user = Cookies.get('user');
                if (user) {
                    user = JSON.parse(user);
                    //用户名作为角色名
                    commit('SET_ROLES', [user.name]);
                    commit('SET_USER', user);
                    resolve(user);
                } else {
                    reject(false);
                }
            });
        },

        //注册
        Regist({ commit }, registInfo) {
            let { name, password, repeatPassword } = registInfo;
            return new Promise((resolve, reject) => {
                regist(name, password, repeatPassword).then(response => {
                    resolve(response.data);
                });
            }).catch(error => {
                reject(error)
            });
        },

        //获取验证码
        GetCode({ commit }, phone) {
            let _phone = phone;
            return new Promise((resolve, reject) => {
                getCode(_phone).then(response => {
                    resolve(response.data);
                });
            }).catch(error => {
                reject(error)
            });
        },

        // 登出
        LogOut({ commit, state }) {
            return new Promise((resolve, reject) => {
                logout().then(response => {
                    commit("LOGOUT_USER");
                    resolve();
                }).catch(error => {
                    reject(error)
                });
            });
        }

    }
};

export default user;