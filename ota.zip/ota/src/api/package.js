//升级包名称管理


/*
新增升级包名称
"userId":28,				//必填
"terminal_id":15,			//终端类型id，	必填
"package_name":"智能电表测试包1"	,	//升级包名称，必填
"introduce":"fadsfasdfafa"		//简介，选填
*/
export function addPackage(userId,terminal_id,package_name,introduce) {
	const data = {userId,terminal_id,package_name,introduce};
    return fetch({
        url: '/ong/package?cmd=add_package',
        method: "post",
        data
    })
}

//更新升级包信息
export function updatePackage(userId,terminal_id,package_id,package_name,introduce) {
	const data = {userId,terminal_id,package_id,package_name,introduce};
    return fetch({
        url: '/ong/package?cmd=update_package',
        method: "post",
        data
    })
}

/*
获取升级包名称列表 
userId  必填
terminal_id  必填
*/
export function getPackageList(userId,terminal_id,package_id,package_name) {
	const params = {userId,terminal_id,package_id,package_name};
    return fetch({
        url: '/ong/package?cmd=get_packages',
        method: "get",
        params
    })
}

/*
删除升级包名称
"userId":28,	必填
"terminal_id":3,	必填
"package_id":24		必填
*/
export function deletePackage(userId,terminal_id,package_id) {
	const params = {userId,terminal_id,package_id,package_name};
    return fetch({
        url: '/ong/package?cmd=delete_package',
        method: "get",
        params
    })
}