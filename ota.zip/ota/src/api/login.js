import fetch from 'utils/fetch';

//获取公钥
export function getPublicKey(){
    return fetch({
        url: '/ota/rsa/publicKey',
        method: 'get'
    });
}

//登录
export function login(data) {
    return fetch({
        url: '/ota/user/login',
        method: 'post',
        data
    });
}

//登出
export function logout() {
    return fetch({
        url: '/ota/user/logout',
        method: 'post'
    });
}

//获取用户信息
export function getInfo(token) {
    return fetch({
        url: '/user/info',
        method: 'get',
        params: { token:"admin" }
    });
}



//注册的时候获取短信验证码
export function getCode(phone){
    return fetch({
        url:'/ong/user?cmd=get_verifyCode',
        method:'get',
        params:{
            phone:phone
        }
    });
}

//注册用户
export function regist(name,password,repeatPassword){
    const data = {
        name,
        password,
        repeatPassword
    }
    return fetch({
        url:'/ota/user/registor',
        method:'post',
        data,
    });
}