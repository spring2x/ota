import fetch from 'utils/fetch';

//获取用户列表
export function getUserList() {
    return fetch({
        url: '/ota/user/getUsers',
        method: 'post'
    });
}