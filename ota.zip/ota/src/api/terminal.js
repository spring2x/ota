import fetch from 'utils/fetch';
import Cookies from 'js-cookie';

/*
添加终端
用户id，必填
终端类型名称，必填
业务平台认证的url，必填
简介，选填
*/


export function addTerminal(data) {
    return fetch({
        url: '/ong/terminal?cmd=add_terminal',
        method: "post",
        data
    })
}


//更新终端信息
export function updateTerminal(data) {
    return fetch({
        url: '/ong/terminal?cmd=update_terminal_info',
        method: "post",
        data
    })
}

/*
添加终端的使用用户
需要被添加的用户id，必填
终端类型id,必填
当前操作的用户（已经登陆的用户）id,必填
添加用户的终端权限(1—管理员权限（读、写），2—普通用户权限（读）)，必填
*/
export function addTerminalUseUser(userId, terminal_id, cur_userId, competence_type) {
    const data = { userId, terminal_id, cur_userId, competence_type };
    return fetch({
        url: '/ong/terminal?cmd=add_terminal_user',
        method: "post",
        data
    })
}

/*
更新终端用户的使用权限
*/
export function uppdateTerminalUser(userId, terminal_id, cur_userId, competence_type) {
    const data = { userId, terminal_id, cur_userId, competence_type };
    return fetch({
        url: '/ong/terminal?cmd=update_terminal_user_competence',
        method: "post",
        data
    }) 
}


/*
获取终端类型列表
terminal_id	终端类型id，选填
userId		用户id，选填
competence_type	用户终端权限，选填
*/
export function getTerminalList() {
    const data = {
        
    }
    return fetch({
        url: '/ong/terminal/get_terminals',
        method: "post",
        data
    })
}
/*
获取权限列表
@return 
type 0 1 2  
*/
export function getCompetenceList() {
    return fetch({
        url: '/ong/terminal/get_terminal_competence',
        method: "post"
    })
}

/*
删除终端类型  delete_terminals
*/
export function deleteTerminal(userId,terminal_id) {
	const data = {userId,terminal_id};
    return fetch({
        url: '/ong/terminal/deleteTerminal',
        method: "post",
        data
    })
}
/*
添加终端的使用用户
*/
export function addTerminalUser(cur_userId,terminal_id,userId,competence_type){
    const data = {cur_userId,terminal_id,userId,competence_type};
    return fetch({
        url: '/ong/terminal?cmd=add_terminal_user',
        method: "post",
        data
    });
}

/*
获取终端以及人员信息 get_user_terminal_competence
*/
export function getTerminalUser(terminal_id){
    return fetch({
        url: '/ong/terminal/get_user_terminal_competence',
        method: "post",
        data:{terminal_id}
    })
}
/*
新增升级包名称*/
export function addPackage(p){
    const data = p;
    return fetch({
        url: '/ong/package?cmd=add_package',
        method: "post",
        data
    })
}
/*
更新升级包信息*/
export function updatePackage(p){
    const data = p;
    return fetch({
        url: '/ong/package?cmd=update_package',
        method: "post",
        data
    })
}
/*
获取升级包名称列表*/
export function getPackages(data){
    return fetch({
        url: '/ong/package/get_packages',
        method: "post",
        data
    })
}
/*
删除升级包名称*/
export function deletePackage(data){
    return fetch({
        url:'/ong/package/delete_package',
        method:"post",
        data
    })
}
/*
添加升级包版本信息*/
export function addVersion(data){
    return fetch({
        url: '/ong/version?cmd=add_version',
        method: "post",
        data
    })
}
/*
更新升级包版本信息*/
export function updateVersion(data){
    return fetch({
        url: '/ong/version?cmd=update_package_version',
        method: "post",
        data
    })
}
/*
获取升级包的版本信息*/
export function getVersionList(userId,package_id){
    const data ={userId,package_id};
    return fetch({
        url: '/ong/version/get_package_version_info',
        method: "post",
        data
    })
}
/*
删除升级包版本信息*/
export function delVersion(userId,version_id){
    const data ={userId,version_id};
    return fetch({
        url: '/ong/version/delete_package_version',
        method: "post",
        data
    })
}


export function downLoad(){
    const data =    {
            "terminal_id":"2",
            "package_id":"2",
    "package_version_id":"2"    
}
    return fetch({
        url: '/ong/packageFile/packageFilesInfo',
        method: "post",
        data
    })
}

