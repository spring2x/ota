// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import "babel-polyfill";
import Vue from 'vue';
import App from './App';
import router from './router'; 
import store from './store';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-default/index.css';
//import 'assets/custom-theme/index.css'; // 换肤版本element-ui css
import NProgress from 'nprogress'; // Progress 进度条
import 'nprogress/nprogress.css'; // Progress 进度条 样式
import 'normalize.css/normalize.css'; // normalize.css 样式格式化
import 'assets/iconfont/iconfont'; // iconfont 
import * as filters from './filters'; // 全局vue filter
import IconSvg from 'components/Icon-svg'; // svg 组件
import errLog from './store/errLog'; // error log组件
import './mock/index.js'; // 该项目所有请求使用mockjs模拟
import $ from 'jquery';
// register globally
Vue.component('icon-svg', IconSvg)
Vue.use(ElementUI);
// register global utility filters.
Object.keys(filters).forEach(key => {
    Vue.filter(key, filters[key])
});

// 判断角色访问权限，该系统虽然没有要求，但是逻辑在
function hasPermission(roles, permissionRoles) {
    if (roles.indexOf('admin') >= 0) return true; 
    if (!permissionRoles) return true;
    return roles.some(role => permissionRoles.indexOf(role) >= 0)
}

// register global progress.
const whiteList = ['/login', '/regist']; // 不重定向白名单
router.beforeEach((to, from, next) => {
    NProgress.start(); // 开启Progress
    const token = store.getters.token;
    if (token) { // 判断是否有token
        if (to.path === '/login') {
            next({ path: '/' });
        } else {
            if (store.getters.roles.length === 0 ) { // 判断当前用户是否已拉取完user_info信息
                store.dispatch('GetInfo').then(res => { // 拉取user_info
                    //这里没有角色的概念 以用户名作为角色名字 
                    const roles = [res.name];
                    store.dispatch('GenerateRoutes', { roles }).then(() => { // 生成可访问的路由表
                        router.addRoutes(store.getters.addRouters) // 动态添加可访问路由表
                        next({ ...to }); // hack方法 确保addRoutes已完成
                    })
                }).catch(error=>{

                });
            } else {
                // 没有动态改变权限的需求可直接next() 删除下方权限判断 ↓
                if (hasPermission(store.getters.roles, to.meta.role)) {
                    next(); //
                } else {
                    next({ path: '/401', query: { noGoBack: true } });
                }
                // 可删 ↑
            }
        }
    } else {
        if (whiteList.indexOf(to.path) !== -1) { // 在免登录白名单，直接进入
            next()
        } else {
            next('/login'); // 否则全部重定向到登录页
            NProgress.done(); 
        }
    }
});

router.afterEach(() => {
    NProgress.done(); // 结束Progress
});

Vue.config.productionTip = false;

// 生产环境错误日志
if (process.env === 'production') {
    Vue.config.errorHandler = function(err, vm) {
        console.log(err, window.location.href);
        errLog.pushLog({
            err,
            url: window.location.href,
            vm
        })
    };
}

new Vue({
    el: '#app',
    router,
    store,
    template: '<App/>',
    components: { App }
})


Vue.config.devtools = true