import Mock from 'mockjs';
//演示mock
import articleAPI from './article';
Mock.mock(/\/article\/list/, 'get', articleAPI.getList);
export default Mock;
