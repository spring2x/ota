const compenenceArray = [{
        "id": 1,
        "introduce": "超级管理员权限，对终端具有所有增删改查权限",
        "name": "超级管理员",
        "type": 0
    },
    {
        "id": 2,
        "introduce": "管理员权限，对终端只具有增加、修改、查看权限",
        "name": "管理员",
        "type": 1
    },
    {
        "id": 3,
        "introduce": "普通权限，对终端只有查看权限",
        "name": "普通用户",
        "type": 2
    }
]


export { compenenceArray };