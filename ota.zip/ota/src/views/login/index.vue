<template>
  <div class="login-container">
    <el-form autoComplete="off" :model="loginForm" :rules="loginRules" ref="loginForm" label-position="left" label-width="0px"
      class="card-box login-form">
      <h3 class="title">平台登录</h3>
      <el-form-item prop="name">
        <span class="svg-container"><icon-svg icon-class="xinrenzhinan"></icon-svg></span>
        <el-input name="name" type="text" v-model="loginForm.name" autoComplete="off" placeholder="用户名"></el-input>
      </el-form-item>
      <el-form-item prop="password">
        <span class="svg-container"><icon-svg icon-class="mima"></icon-svg></span>
        <el-input name="password" type="password" v-model="loginForm.password" autoComplete="off" placeholder="密码"></el-input>
      </el-form-item>
      <el-form-item prop="validCode" class="code-box">
        <span class="svg-container"><icon-svg icon-class="bug"></icon-svg></span>
        <el-input class="valid-code" name="validCode"  v-model="loginForm.validCode" autoComplete="off" placeholder="验证码"></el-input>
        <div id="code-wrap">
          <img :src="imgsrc" alt="">
          <span  @click="refreshCode" >换一张</span>
        </div>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" style="width:100%;" :loading="loading" @click.native.prevent="handleLogin">
          登录
        </el-button>
      </el-form-item>
      <div class="tips">
            <router-link to="/regist" class="fr">没有账号？立即注册</router-link>
      </div>
    </el-form>

  </div>
</template>
 
<script>
  import { validatePhone,validatePass } from 'utils/validate';
  import { getPublicKey } from 'api/login';
  import  RSA from 'utils/RSA';
  export default {
    components: {  },
    name: 'login',
    data() {
      return {
        loginForm: {
          name: '',
          password: '',
          validCode:""
        },
        loginRules: {
          name: [
                { required: true, trigger: 'blur',message:"必填"}
          ],
          password: [
                { required: true, trigger: 'blur',message:"必填"}
          ],
          validCode:[
              {required:true,trigger:"blur",message:"必填"}
          ]
        },
        loading: false,
        imgsrc:'/ota/validCode/get'
      }
    },
    methods: {
      refreshCode(){
        let timestamp = +new Date();
        let imgsrc = this.imgsrc;
        this.imgsrc=imgsrc+"?timestamp="+timestamp;
      },

      handleLogin() {
        this.$refs.loginForm.validate(valid => {
          if (valid) {
            //获取公钥
            getPublicKey().then(res=>{
              let pass =  this.loginForm.password;
              const json = res.data;
              if(json.code!="0000"){
                this.$message(json.data);
                return;
              }
              const {exponent ,modulus ,privateKeyId} = json;
              //对称加密
              let publicKey = RSAUtils.getKeyPair(exponent, '', modulus);
              let encryptedPassword = RSAUtils.encryptedString(publicKey, pass);
              
              this.loading = true;
              const {name,validCode}= this.loginForm;
              //分发登录action
              this.$store.dispatch('Login',{name,password:encryptedPassword,validCode,privateKeyId}).then((json) => {
                this.loading = false;
                if(json.code=="0000"){
                  this.$router.push({ path: '/' });
                }else{
                  this.$message(json.message);
                }
              }).catch(err => {
                this.$message.error(err);
                this.loading = false;
              });
            })  
              
          } else {
            console.log('error submit!!');
            this.loading = false;
            return false;
          }
        });
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" >
  @import "src/styles/mixin.scss";
  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 5px;
  }

  .login-container {
    @include relative;
    height: 100vh;
    background-color: #2d3a4b;
    input:-webkit-autofill {
      -webkit-box-shadow: 0 0 0px 1000px #293444 inset !important;
      -webkit-text-fill-color: #fff !important;
    }
    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: #eeeeee;
      height: 47px;
    }
    .el-input {
      display: inline-block;
      height: 47px;
      width: 85%;
    }
    .el-input.valid-code{
      width: 100px;
      border-right: 1px #3e4650 solid;
    }
    .code-box{
      position: relative;
    }
    #code-wrap{
      position: absolute;
      right: 10px;
      top: 5px;
      color: #20a0ff;
      img{
        height: 36px;
        vertical-align: middle;
        margin-right: 10px;
      }
      span{
        cursor:pointer;
      }
    }
    .svg-container {
      padding: 6px 5px 6px 15px;
      color: #889aa4;
    }
    .title {
      font-size: 26px;
      font-weight: 400;
      color: #eeeeee;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }
    .login-form {
      position: absolute;
      left: 0;
      right: 0;
      width: 400px;
      padding: 35px 35px 15px 35px;
      margin: 120px auto;
    }
    .el-form-item {
      border: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      color: #454545;
    }
    .forget-pwd {
      color: #fff;
    }
  }
</style>
