<template>
  <div class="components-container">
    <el-form :inline="true" >
        <el-form-item>
          <router-link to="/terminal/list">
            <el-button type="text">
              <i class="el-icon-arrow-left"></i>返回
            </el-button>
          </router-link>
        </el-form-item>
        <el-form-item class="fr">
          <el-button type="primary" v-if="terminalOwnerId==loginUserId" size="small" @click="dialogAddUserVisible=true"><i class="el-icon-plus"></i>添加使用用户</el-button>
        </el-form-item>
    </el-form>
    <el-table
    :data="list" 
    style="width: 100%"
    :row-class-name="tableRowClassName"
    :highlight-current-row="highlight"
    v-loading.body="loading"
    element-loading-text="拼命加载中"
    >
      <el-table-column
        type="index"
        width="50">
      </el-table-column>
      <el-table-column
        prop="userName"
        label="用户名">
      </el-table-column>
      <el-table-column
        prop="competenceType"
        label="权限"
        scope="scope"
        :formatter="handleType"
        >
      </el-table-column>
      <el-table-column 
      label="操作"
      width="200"
      >
        <template scope="scope">
          <el-button @click="showUpdateDailog(scope.row)" type="primary" size="small" 
          :disabled="terminalOwnerId!=loginUserId || scope.row.competenceType==0 ">更新权限</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="更新权限" :visible.sync="dialogFormVisible" :lock-scroll=true size="tiny" @close="resetForm('termialForm')" >
        <el-form  ref="termialForm" label-width="80px">
          <el-form-item label="权限">
            <el-select v-model="selectedUserCompetenceType" placeholder="请选择">
              <el-option
                v-for="item in compenenceArray"
                :key="item.id"
                :label="item.name"
                :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="updateUserCompetence">确定</el-button>
          <el-button @click="dialogFormVisible=false;">取消</el-button>
        </div>
    </el-dialog>
    <el-dialog title="添加使用用户" :visible.sync="dialogAddUserVisible" :lock-scroll=true size="tiny" 
    @close="resetForm('userForm')"
     >
        <el-form :model="userForm" :rules="rules" ref="userForm" label-width="120px">
          <el-form-item label="被添加的用户" prop="userId">
            <el-select v-model="userForm.userId" placeholder="请选择人员">
                <el-option
                  v-for="item in userList"
                  :key="item.id"
                  :value="item.id"
                  :label="item.uname"
                ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="权限" prop="competence_type">
            <el-select v-model="userForm.competence_type" placeholder="请选择">
              <el-option
                v-for="item in compenenceArray"
                :key="item.id"
                :label="item.name"
                :value="item.type">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="addUser()">添加</el-button>
          <el-button @click="dialogAddUserVisible=false;">取消</el-button>
        </div>
    </el-dialog>  
  </div>
</template>


<script>
  import { getTerminalUser,addTerminalUser,uppdateTerminalUser } from 'api/terminal';
  import { getUserList } from 'api/user'
  import { compenenceArray } from 'utils/config';
  export default {
    methods: {
      handleType(row, column, cellValue){
        const p = row.competenceType;
        for(let i=0;i<compenenceArray.length;i++){
          if(p==compenenceArray[i].type) return compenenceArray[i].name;
        }
      },
      tableRowClassName(row, index) {
        if (index === 1) {
          return 'info-row';
        } else if (index === 3) {
          return 'positive-row';
        }
        return '';
      },
      fetchUserList(){
          getUserList().then((response)=>{
            const data = response.data;
            if(data.code==="0000"){
              this.userList=data.users.userArray;
            }else{
              this.$message(data.message);
            }
          }).catch((error)=>{
              this.$message({message:"服务器出错了！",type:"error"});
          });
      },
      fetchData( ){
        this.loading=true;
        getTerminalUser(this.$route.params.terminalId).then((response)=>{
          this.loading=false;
          const data = response.data;
          if(data.code==="0000"){
            this.list=data.terminals.terminalArray;
            this.list.forEach(item=>{ 
              console.log(item)
              if(item.competenceType==0){
                  this.terminalOwnerId=item.userId;
              }; 
            });
          }else{
            this.$message.warning(data.message);
          }
        }).catch((error)=>{
          this.loading=true;
            this.$message({message:"服务器出错了！",type:"error"});
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },
      showUpdateDailog(row){
        this.dialogFormVisible = true;
        this.selectedUserCompetenceType = row.competenceType;
        this.selectedUserId = row.userId;
      },
      updateUserCompetence(){
        const cur_userId = this.$store.getters.userId;
        const terminal_id = this.$route.params.terminalId;
        uppdateTerminalUser(this.selectedUserId,terminal_id,cur_userId,this.selectedUserCompetenceType)
        .then(response=>{
          const data = response.data;
          if(data.code=="0000"){
            this.$message.success("操作成功！");
            this.fetchData();
          }else{
            this.$message.warning(data.message);
          }
          this.dialogFormVisible=false;
        })
        .catch(error=>{
          this.$message.error(error.message);
        });
      },
      addUser(){
        this.$refs.userForm.validate(valid=>{
          if(valid){
            this.dialogAddUserVisible = false;
            const cur_userId = this.$store.getters.userId;
            const terminal_id = this.$route.params.terminalId;
            addTerminalUser(cur_userId,terminal_id,this.userForm.userId,this.userForm.competence_type).then(response=>{
              const data = response.data;
              if(data.code=="0000"){
                this.$message.success("添加成功");  
                this.fetchData();
              }else{
                this.$message.warning(data.message);
              }
            }).catch(error=>{
              this.$message.error(error.message?error.message:"服务器出错了！")
            });
            this.$refs.userForm.resetFields();
          }
        })
      }
    },
    data() {
      return {
        list:[],
        userList:[],
        loading:false,
        highlight:true,
        dialogFormVisible:false,
        dialogAddUserVisible:false,
        selectedUserCompetenceType:'',
        selectedUserId:'',
        compenenceArray:compenenceArray,
        loginUserId:this.$store.getters.userId,//当前登录用户Id
        terminalOwnerId:"",//终端拥有者id
        userForm:{
          userId:"",
          competence_type:""
        },
        rules: {
          userId: [
            { required: true, type:"number", message: '需要被添加的用户id必填', trigger: 'blur' }
          ],
          competence_type: [
            { required: true, type:"number", message: '添加用户的终端权限必填', trigger: 'change' }
          ]
        }
      }
    },
    created(){
      this.fetchData();
      this.fetchUserList();
    },
    watch: {
      '$route': 'fetchData' // 如果路由有变化，会再次执行该方法
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .el-table .info-row {
    background: #c9e5f5;
  }

  .el-table .positive-row {
    background: #e2f0e4;
  }
</style>