<template>
  <div class="components-container">
      <div class="clearfix item-wrap">
        <div>
          <el-alert
            title="终端管理列表"
            type="info"
            close-text="添加终端"
            description="你可以在此进行终端人员信息和升级包管理"
            @close="toAdd"
            center
            show-icon
            >
        </el-alert>
        </div>
        <div v-for="(item,index) in list" class="card-item" >
          <el-card class="card-block" :body-style="{ padding: '10px' }">
            <div slot="header" class="clearfix">
                <span style="line-height: 36px;">{{item.terminalType}}&nbsp;(id={{item.terminalId}})</span>
                <el-button type="text" class="button" @click="del(item)">
                  <i class="el-icon-delete"></i>
                </el-button>
                <el-button type="text" class="button" @click="showEditDailog(item)" >
                  <i class="el-icon-edit"></i>
                </el-button>
            </div>
            <div class="info">
              <p class="intro"><b>所有者：</b>{{item.userName}}</p>
              <p class="intro"><b>认证URL：</b></br>{{item.platformUrl}}</p>
              <p class="intro"><b>简介：</b></br>{{item.terminalIntroduce}}</p>
            </div>
            <div class="bottom clearfix">
              <el-button type="text" class="button" @click="toUser(item)">人员信息</el-button>
              <el-button type="text" class="button" @click="toPackage(item)">升级包管理</el-button>
            </div>
          </el-card>
        </div>
     </div>  

     <el-dialog title="更新终端信息" :visible.sync="dialogFormVisible" :lock-scroll=true size="tiny" >
        <el-form :model="termialForm" :rules="rules" ref="termialForm" label-width="140px">
          <el-form-item label="终端类型名称" prop="type">
            <el-input :maxlength=60  v-model="termialForm.type" ></el-input>
          </el-form-item>
          <el-form-item label="业务平台认证URL" prop="businessPlatformUrl">
            <el-input :maxlength=100 v-model="termialForm.businessPlatformUrl"></el-input>
          </el-form-item>
          <el-form-item label="简介" prop="introduce">
            <el-input :maxlength=120 type="textarea"  v-model="termialForm.introduce"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="update()">更新</el-button>
          <el-button @click="dialogFormVisible=false">取消</el-button>
        </div>
    </el-dialog> 
  </div>
  
</template>

<script>
  import { validateURL } from 'utils/validate';
  import { getTerminalList,deleteTerminal,updateTerminal } from 'api/terminal';
  import { compenenceArray } from 'utils/config';
  export default { 
    methods: {
      toAdd() {
        this.$router.push({ path: '/terminal/add'});
      },
      handleType(row, column, cellValue){
        const p = row.competenceType;
        if(p==0){
          return "超级管理员";
        }
        if(p==1){
          return "管理员";
        }
        if(p==2){
          return "普通用户";
        }
      },
      tableRowClassName(row, index) {
        if (index === 1) {
          return 'info-row';
        } else if (index === 3) {
          return 'positive-row';
        }
        return '';
      },
      toUser({terminalId}){
        this.$router.push({ path: '/terminal/userList/'+terminalId});
      },
      toPackage({terminalId}){
        this.$router.push({ path: '/terminal/packageList/'+terminalId});
      },
      fetchData(){
        this.loading=true;
        const userId = this.$store.getters.userId;
        getTerminalList({userId}).then((response)=>{
          this.loading=false;
          const data = response.data;
          if(data.code==="0000"){
            const terminalArray = data.terminals.terminalArray;
            this.list=terminalArray;
            if(terminalArray.length<=0){
              this.$alert('您还没有任何终端设备，立即添加？', '提示', {
                confirmButtonText: '立即添加',
                callback: action => {
                  this.$router.push({ path: '/terminal/add'});
                }
              });
            }
          }else{
            this.$message.warning(data.message);
          }
        }).catch((error)=>{
            this.loading=true;
            this.$message.error(error.message?error.message:"服务器出错了！");
        });
      },
      del( {terminalId,terminalType}){
        this.$confirm("确定要删除"+terminalType+"?").then(_=>{
          deleteTerminal(this.userId,terminalId).then(response=>{
            const data = response.data;
            if(data.code==="0000"){
              this.$message.success("删除成功");
              this.fetchData();
            }else{
              this.$message.warning(data.message);
            }
          }).catch(error=>{
              this.$message.error(error.message?error.message:"服务器出错了！");
          });
        }).catch(_=>{});
      },
      showEditDailog(terminal){
        this.dialogFormVisible = true;
        this.termialForm={
          businessPlatformUrl: terminal.platformUrl,
          terminal_id:terminal.terminalId,
          type:terminal.terminalType,
          introduce:terminal.terminalIntroduce,
          userId:this.userId
        };
      },
      update(){
        this.$refs.termialForm.validate(valid=>{
          if(valid){
              this.dialogFormVisible = false;
              updateTerminal(this.termialForm).then(response=>{
                const data = response.data;
                if(data.code="0000"){
                  this.$message.success("更新成功");
                  this.fetchData();
                }else{
                  this.$message.warning(data.message);
                }
              }).catch(error=>{
                  this.$message.error(error.message?error.message:"服务器出错了！")
              });
          }
        });
      }
    },
    data() {
       var urlValidator = (rule,value,callback)=>{
        if(!validateURL(value)) {
          callback(new Error('URL格式不正确'));
        }else {
          callback();
        }
      };
      return {
        list:[],
        loading:false,
        highlight:true,
        dialogFormVisible:false,
        userId:this.$store.getters.userId,
        termialForm: {
          businessPlatformUrl: '',
          terminal_id:'',
          type: '',
          introduce:'',
          userId:""
        },
        rules: {
          businessPlatformUrl: [
            { required: true, message: '业务平台认证URL必填', trigger: 'blur' },
            { max: 100, message: 'URL长度不能超过100', trigger: 'blur' },
            { validator: urlValidator, trigger: 'blur' },
          ],
          type: [
            { required: true, message: '终端类型名称必填', trigger: 'blur' },
            { max: 60, message: '名称长度不能超过60', trigger: 'blur' }
          ],
          introduce:[
            {max:120,message:'简介太长',trigger:"blur"}
          ]
        }
      }
    },
    created(){
      this.fetchData();
    },
    filters:{
      competenceTypeToText( p ){
        for(let i=0;i<compenenceArray.length;i++){
          if(p==compenenceArray[i].type) return compenenceArray[i].name;
        }
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .item-wrap{
    width: 1300px;
    margin: 0 auto;
    .card-item{
        float:left;
        height: 300px;
        width: 33.33%;
        padding: 20px;
        .card-block{
          height: 100%;
          width: 100%;
          .info{
            height: 130px;
            overflow-y: auto;
          }
          .intro,.url{
              font-size: 14px;
              color: gray;
              margin:5px 0px;
          }
      }
    }
  }
  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }
  .button {
    padding: 0;
    float: right;
    margin-right:15px;
  }
</style>