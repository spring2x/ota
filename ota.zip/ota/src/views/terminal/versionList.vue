<template>
	<div class="components-container">
		<el-form :inline="true" >
	        <el-form-item>
		        <el-button type="text" @click="goBack()">
		          <i class="el-icon-arrow-left"></i>返回
		        </el-button>
	        </el-form-item>
	        <el-form-item class="fr">
	          <el-button type="primary" size="small" @click="dialogVersionVisible=true"><i class="el-icon-plus"></i>添加版本</el-button>
	        </el-form-item>
	    </el-form>

	    <el-table
	    :data="list"
	    style="width: 100%"
	    :highlight-current-row="highlight"
	    v-loading.body="loading"
	    element-loading-text="拼命加载中"
	    >
	      <el-table-column
	        type="index"
	        width="50">
	      </el-table-column>
	      <el-table-column
	        prop="package_version_id"
	        label="版本ID">
	      </el-table-column>
	      <el-table-column
	        prop="package_id"
	        label="升级包ID">
	      </el-table-column>
	      <el-table-column
	        prop="terminal_id"
	        label="终端ID">
	      </el-table-column>
	      <el-table-column
	        prop="package_version"
	        label="版本">
	      </el-table-column>
	      <el-table-column
	        prop="package_version_introduce"
	        label="描述"
	        >
	      </el-table-column>
	      <el-table-column 
	      label="操作"
	      width="300">
	        <template scope="scope">
	          <el-button @click="del(scope.row)" type="primary" icon="delete" size="small">删除</el-button>
	          <el-button @click="showUpdateDailog(scope.row)" type="primary" icon="edit" size="small">编辑</el-button>
	          <el-button @click="showUploadDailog(scope.row)" type="primary" icon="upload" size="small" v-if="!scope.row.filePath">上传包</el-button>
	          <el-button  type="text"  v-if="scope.row.filePath" ><a :href="scope.row.filePath" target="_blank">下载包</a></el-button>
	        </template>
	      </el-table-column>
	    </el-table>

	    

		<el-dialog title="添加版本" :visible.sync="dialogVersionVisible" 
	    	:lock-scroll="true" 
	    	size="tiny"
	     	@close="resetForm('versionForm')">
	        <el-form :model="versionForm" :rules="rules" ref="versionForm" label-width="70px">
	          <el-form-item label="版本号" prop="package_version">
	            <el-input v-model="versionForm.package_version" :maxlength=60 placeholder="版本号"></el-input>
	          </el-form-item>
	          <el-form-item label="描述" prop="introduce">
	            <el-input type="textarea" :maxlength=120 v-model="versionForm.introduce" placeholder="描述"></el-input>
	          </el-form-item>
	        </el-form>
	        <div slot="footer" class="dialog-footer">
	          <el-button type="primary" @click="addVersion()">添加</el-button>
	          <el-button @click="dialogVersionVisible=false;">取消</el-button>
	        </div>
	    </el-dialog>  

	    <el-dialog title="更新版本" :visible.sync="dialogUpdateVisible" 
	    	:lock-scroll="true" 
	    	size="tiny"
	     	@close="resetForm('updateVersionForm')">
	        <el-form :model="updateVersionForm" :rules="rules" ref="updateVersionForm" label-width="70px">
	          <el-form-item label="版本号" prop="package_version">
	            <el-input v-model="updateVersionForm.package_version" :maxlength=60 placeholder="版本号"></el-input>
	          </el-form-item>
	          <el-form-item label="描述" prop="introduce">
	            <el-input type="textarea" :maxlength=120 v-model="updateVersionForm.introduce" placeholder="描述"></el-input>
	          </el-form-item>
	        </el-form>
	        <div slot="footer" class="dialog-footer">
	          <el-button type="primary" @click="updateVersion()">确定</el-button>
	          <el-button @click="dialogUpdateVisible=false;">取消</el-button>
	        </div>
	    </el-dialog>  

	    <el-dialog title="包上传" :visible.sync="dialogUploadVisible" 
	    	:lock-scroll="true" 
	    	size="tiny"
	     	>
	        <el-upload 
			  class="upload-box"
			  drag
			  name="file"
			  :on-success="fileUpSuccess"
			  :on-error="fileUpError"
			  :on-preview="handlePreview"
			  :before-upload="beforeUpload"
			  :headers="headers"
			  action="/ong/packageFile/upload"
			  ref="test"
			  multiple
			  :data="data"
			  >
			  <i class="el-icon-upload"></i>
			  <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
			  <div class="el-upload__tip" slot="tip">文件大小不超过50000M</div>
			</el-upload>
	        <div slot="footer" class="dialog-footer">
	          <el-button type="primary" @click="updateVersion()">确定</el-button>
	          <el-button @click="dialogUploadVisible=false;">取消</el-button>
	        </div>
	    </el-dialog> 
		<!-- 用post提交表单下载升级包 -->
	          <form action=""></form>

	</div>
</template>

<script>
import {getVersionList,delVersion,addVersion as doAddVersion ,updateVersion as doUpdateVersion,downLoad as doDownLoad} from 'api/terminal';
export default {
	methods:{
		goBack(){
			this.$router.go(-1);
		},
		resetForm(formName){
			this.$refs[formName].resetFields();
		},
		downLoad(data){
			doDownLoad(data);
		},
		addVersion(){
			this.$refs.versionForm.validate(valid=>{
				if(valid){
					const params = {
						introduce:this.versionForm.introduce,
						package_id:this.versionForm.package_id,
						package_version:this.versionForm.package_version,
						userId:this.versionForm.userId
					}
					doAddVersion(params).then(response=>{
						const data = response.data;
						if(data.code=="0000"){
							this.$message.success("添加成功！");
							this.fetchData();
						}else{
							this.$message.warning(data.message);
						}
					}).catch(error=>{
						this.$message.error(error.message?error.message:"服务器出错了！");
					});
					this.dialogVersionVisible=false;
				}
			})
		},
		del(version){
			this.$confirm("确定要删除:"+version.package_version+" 版本?", '提示', {
	          confirmButtonText: '确定',
	          cancelButtonText: '取消',
	          type: 'warning'
	        }).then(() => {
	          delVersion(this.params.userId,version.package_version_id)
	          .then(response=>{
	          	const data = response.data;
	          	if(data.code=="0000"){
	          		this.$message.success("删除成功！");
	          		this.fetchData();
	          	}else{
	          		this.$message.warning(data.message);
	          	}
	          }).catch(error=>{
	          		this.$message.error("服务器出错了！")
	          })
	        }).catch(() => {
	                 
	        });
		},
		showUploadDailog(version){
			this.dialogUploadVisible=true;
			this.data.package_version_id=version.package_version_id;
		},
		showUpdateDailog(version){
			this.dialogUpdateVisible=true;
			this.updateVersionForm.introduce= version.package_version_introduce;
			this.updateVersionForm.version_id= version.package_version_id;
			this.updateVersionForm.package_version= version.package_version;

		},
		updateVersion(){
			doUpdateVersion(this.updateVersionForm).then(response=>{
				const data = response.data;
				if(data.code=="0000"){
					this.$message.success("更新成功！");
					this.fetchData();
				}else{
					this.$message.warning(data.message);
				}
				this.dialogUpdateVisible= false;
			}).catch(error=>{
				this.$message.error("服务器出错了！");
			});
		},
		fetchData(){
			getVersionList(this.params.userId,this.params.package_id*1).then(response=>{
				const data = response.data;
				if(data.code=="0000"){
					this.list=data.package_version_info;
				}else{
					this.$message.warning(data.message);
				}
			}).catch(error=>{
				this.$message.error("服务器出错了！")
			})
		},
		fileUpSuccess(json){
			if(json.code=="0000"){
				this.$message.success("上传升级包成功！");
				this.fetchData();
			}else{
				this.$message.warning(json.message);
			}
			this.dialogUploadVisible =false;
		},
		fileUpError(json){
			this.$message.error("服务器出错了！")
			this.dialogUploadVisible =false;
		},
		handlePreview(){

		},
		beforeUpload(file){
			const isLt50M = file.size/1024/1024 < 50000;
			if(isLt50M){
				return true;
			}else{
				this.$message.warning("文件大小不超过50000M");
				return false;
			}
		}
	},
	data(){
		return {
			dialogVersionVisible:false,
			dialogUpdateVisible:false,
			dialogUploadVisible:false,
			loading:false,
    		highlight:true,
    		headers:{
				Authorization:this.$store.getters.token
    		},
			data:{
				terminal_id:this.$route.params.terminalId,
				package_id:this.$route.params.packageId,
				package_version_id:""
			},
			list:[],
			params:{
				userId:this.$store.getters.userId,
				package_id:this.$route.params.packageId
			},
			versionForm:{
				userId:this.$store.getters.userId*1,
				package_id:this.$route.params.packageId*1,
				package_version:"",
				introduce:""
			},
			updateVersionForm:{
				userId:this.$store.getters.userId,
				version_id:"",
				package_version:"",
				introduce:""
			},
			rules:{
				package_version:[
					{ required: true, max:60,message: '填写正确的版本号', trigger: 'blur' }
				],
				introduce:[
					{ max:120,message: '描述太长', trigger: 'blur' }
				]
			}
		}
	},
	created(){
		this.fetchData();
	}
}
</script>
<style type="stylesheet/scss" lang="scss" scoped>
	.upload-box .el-upload-dragger{
		 max-width: 100%;
	}
</style>