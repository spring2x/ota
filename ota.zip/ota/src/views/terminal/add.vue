<template>
	<div class="app-container">
  <div class="banner-wrap"></div>    
	<el-row type="flex" class="row-bg" justify="center">
	  <el-col :span="12">
	  	<el-form :model="termialForm" :rules="rules" ref="termialForm" label-width="180px">
  		  <el-form-item label="终端类型名称" prop="type">
  		    <el-input :maxlength=60  v-model="termialForm.type" ></el-input>
  		  </el-form-item>
  		  <el-form-item label="业务平台认证URL" prop="businessPlatformUrl">
  		    <el-input :maxlength=100 v-model="termialForm.businessPlatformUrl"></el-input>
  		  </el-form-item>
  		  <el-form-item label="简介" prop="introduce">
  		    <el-input :maxlength=120 type="textarea"  v-model="termialForm.introduce"></el-input>
  		  </el-form-item>
  		  <el-form-item label-width="180px">
  		    <el-button type="primary" @click="submitForm('termialForm')">立即创建</el-button>
  		    <el-button @click="resetForm('termialForm')">重置</el-button>
  		  </el-form-item>
  		</el-form>
	  </el-col>
	</el-row>
	</div>
</template>
<script>
  import { addTerminal } from 'api/terminal';
  import { validateURL } from 'utils/validate';
  export default {
    data() {
      var urlValidator = (rule,value,callback)=>{
        if(!validateURL(value)) {
          callback(new Error('URL格式不正确'));
        }else {
          callback();
        }
      };
      return {
        termialForm: {
          businessPlatformUrl: '',
          type: '',
          introduce:''
        },
        rules: {
          businessPlatformUrl: [
            { required: true, message: '业务平台认证URL必填', trigger: 'blur' },
            { max: 100, message: 'URL长度不能超过100', trigger: 'blur' },
            { validator: urlValidator, trigger: 'blur' },
           
          ],
          type: [
            { required: true, message: '终端类型名称必填', trigger: 'blur' },
            { max: 60, message: '名称长度不能超过60', trigger: 'blur' }
          ],
          introduce:[
            {max:120,message:'简介太长',trigger:"blur"}
          ]
        }
      };
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const userId = this.$store.getters.userId;
            const terminal = $.extend({userId},this.termialForm);
            addTerminal(terminal).then(response=>{
              const data = response.data;
              if (data.code === "0000") {
                  this.$message("添加成功");
                  this.$refs[formName].resetFields();
              }else{
                this.$message.warning(data.message)
              }
            }).catch(err=>{
              this.$message.error(err);
            })
          } 
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>
<style type="stylesheet/scss" scoped>
  .banner-wrap{
    width: 100%;
    height: 250px;
    margin:0px  auto 30px auto ; 
    background: url(../../assets/banner.jpg)  no-repeat;
    background-size: cover;
  }
</style>