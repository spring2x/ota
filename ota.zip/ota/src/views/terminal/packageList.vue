<template>
  	<div class="components-container">
  		<el-form :inline="true" >
	        <el-form-item>
	          <router-link to="/terminal/list">
	            <el-button type="text">
	              <i class="el-icon-arrow-left"></i>返回
	            </el-button>
	          </router-link>
	        </el-form-item>
	        <el-form-item class="fr">
	          <el-button type="primary" size="small" @click="dialogAddPackageVisible=true"><i class="el-icon-plus"></i>添加升级包</el-button>
	        </el-form-item>
	    </el-form>
		<el-table
	    :data="list"
	    style="width: 100%"
	    :highlight-current-row="highlight"
	    v-loading.body="loading"
	    element-loading-text="拼命加载中"
	    >	
	    	<el-table-column
				type="index"
	    	>
	    	</el-table-column>
        <el-table-column
          prop="package_id"
          label="升级包ID">
        </el-table-column>
        <el-table-column
          prop="package_terminalId"
          label="终端ID">
        </el-table-column>
		    <el-table-column
		      prop="package_name"
		      label="升级包名称">
		    </el-table-column>
		    <el-table-column
		      prop="package_introduce"
		      label="描述">
		    </el-table-column>
		    <el-table-column
				label="操作"
				width=300
		    >
		    	<template scope="scope">
		    		<el-button type="primary" size="small" icon="edit" @click="showEdit(scope.row)">编辑</el-button>	
		    		<el-button type="primary" size="small" icon="delete" @click="del(scope.row)">删除</el-button>	
		    		<el-button type="primary" size="small" icon="information" @click="toVersion(scope.row)">版本管理</el-button>	
		    	</template>
		    </el-table-column>
	    </el-table>

	    <el-dialog title="添加升级包" :visible.sync="dialogAddPackageVisible" 
	    	:lock-scroll="true" 
	    	size="tiny"
	     	@close="resetForm('packageForm')">
	        <el-form :model="packageForm" :rules="rules" ref="packageForm" label-width="70px">
	          <el-form-item label="包名称" prop="package_name">
	            <el-input v-model="packageForm.package_name" :maxlength=100 placeholder="包名称"></el-input>
	          </el-form-item>
	          <el-form-item label="描述" prop="introduce">
	            <el-input type="textarea" :maxlength=120 v-model="packageForm.introduce" placeholder="描述"></el-input>
	          </el-form-item>
	        </el-form>
	        <div slot="footer" class="dialog-footer">
	          <el-button type="primary" @click="addPackage()">添加</el-button>
	          <el-button @click="dialogAddPackageVisible=false;">取消</el-button>
	        </div>
	    </el-dialog>  

	    <el-dialog title="更新升级包" :visible.sync="dialogUpdatePackageVisible" 
	    	:lock-scroll="true" 
	    	size="tiny"
	     	@close="resetForm('updatePackageForm')">
	        <el-form :model="updatePackageForm" :rules="rules" ref="updatePackageForm" label-width="70px">
	          <el-form-item label="包名称" prop="package_name">
	            <el-input v-model="updatePackageForm.package_name" :maxlength=100 placeholder="包名称"></el-input>
	          </el-form-item>
	          <el-form-item label="描述" prop="introduce">
	            <el-input type="textarea" :maxlength=120 v-model="updatePackageForm.introduce" placeholder="描述"></el-input>
	          </el-form-item>
	        </el-form>
	        <div slot="footer" class="dialog-footer">
	          <el-button type="primary" @click="updatePackage()">确定</el-button>
	          <el-button @click="dialogUpdatePackageVisible=false;">取消</el-button>
	        </div>
	    </el-dialog>  


	</div>
</template>
<script>
  import {getPackages,addPackage as doAddPackage,updatePackage as doUpdatePackage,deletePackage} from 'api/terminal';
  import {deepClone} from 'utils';
  import { Loading } from 'element-ui';
  export default {
	methods: {
      fetchData(){
        this.loading=true;
        const params = this.params;
        getPackages(params).then((response)=>{
          this.loading=false;
          const data = response.data;
          if(data.code==="0000"){
            this.list=data.packageArray;
          }else{
            this.$message(data.message);
          }
        }).catch((error)=>{
          	this.loading=true;
            this.$message({message:"服务器出错了！",type:"error"});
        });
      },
      addPackage(){
      	this.$refs.packageForm.validate(valid=>{
      		if(valid){
      			this.dialogAddPackageVisible=false;
      			const data =$.extend(deepClone(this.params),this.packageForm);
     			doAddPackage(data).then(response=>{
     				const data = response.data;
     				if(data.code=="0000"){
     					this.$message.success("添加升级包成功！");
     					this.fetchData();
     				}else{
     					this.$message.warning(data.message);
     				}
     			}).catch(error=>{
     				this.$message.error(error.message?error.message:"服务器出错了！")
     			});
      		}
      	})
      },
      showEdit(p){
		  	this.dialogUpdatePackageVisible = true;
		  	this.updatePackageForm.package_name=p.package_name;
		  	this.updatePackageForm.package_id = p.package_id;
		  	this.updatePackageForm.introduce = p.package_introduce;
		  	this.updatePackageForm.terminal_id = p.package_terminalId;
      },
      updatePackage(){
  		this.$refs.updatePackageForm.validate(valid=>{
  			if(valid){
  				this.dialogUpdatePackageVisible= false;
  				const data = $.extend(deepClone(this.params),this.updatePackageForm);
  				doUpdatePackage(data).then(response=>{
  					const data = response.data;
  					if(data.code=="0000"){
  						this.$message.success("更新成功！");
  						this.fetchData();
  					}else{
  						this.$message.warning(data.message);
  					}
  				}).catch(error=>{
  					this.$message.error(error.message?error.message:"服务器出错了！")
  				})
  			}	
  		})
      },
      del(p){
      	this.$confirm("确定要删除:"+p.package_name+"?","提示",{
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(_=>{
      		let loadingInstance = Loading.service({target:$(".components-container")[0],text:"删除中..."});
  			  const delp = $.extend(deepClone(this.params),p);
      		deletePackage(delp).then(response=>{
      			const data = response.data;
      			loadingInstance.close();
      			if(data.code=="0000"){
					this.$message.success("删除成功！");  
					this.fetchData();    				
      			}else{
      				this.$message.warning(data.message);
      			}
      		}).catch(error=>{
      			loadingInstance.close();
      			this.$message.error(error.message?error.message:"服务器出错了！")
      		})
        }).catch(_=>{

        })
      },
      resetForm(formName){
        this.$refs[formName].resetFields();
      },
      toVersion(p){
      	let packageId = p.package_id;
      	let terminalId = this.params.terminal_id;
      	const path = '/terminal/'+terminalId+'/package/'+packageId+"/versionList";
        this.$router.push({ path});
      }
    },
    data() {
      return {
        list:[],
        loading:false,
        highlight:true,
        dialogAddPackageVisible:false,
        dialogUpdatePackageVisible:false,
        params:{
        	terminal_id:this.$route.params.terminalId
        },
        packageForm:{
        	package_name:"",
        	introduce:""
        },
        updatePackageForm:{
        	package_name:"",
        	introduce:"",
        	package_id:"",
        	terminal_id:""
        },
        rules: {
          package_name: [
            { required: true, message: '名称必填', trigger: 'blur' },
            { max: 100, message: '名称长度不能超过100', trigger: 'blur' }
          ],
          introduce:[
            {max:120,message:'描述太长',trigger:"blur"}
          ]
        }
      }
    },
    created(){
      this.fetchData();
    }
  }
	
</script>