<template>
  <div class="components-container">
    <el-table
    :data="list"
    style="width: 100%"
    :row-class-name="tableRowClassName"
    :highlight-current-row="highlight"
    v-loading.body="loading"
    element-loading-text="拼命加载中"
    >
    <el-table-column
      type="index"
      width="50">
    </el-table-column>
    <el-table-column
      prop="id"
      label="ID">
    </el-table-column>
    <el-table-column
      prop="uname"
      label="用户名">
    </el-table-column>
    <el-table-column
      prop="phone"
      label="手机号">
    </el-table-column>
    <el-table-column
      prop="last_login"
      label="上次登录时间"
      scope="scope"
      :formatter="formateDate"
      >
    </el-table-column>
    </el-table>
  </div>
  
</template>

<style>
  .el-table .info-row {
    background: #c9e5f5;
  }

  .el-table .positive-row {
    background: #e2f0e4;
  }
</style>

<script>
  import {getUserList} from 'api/user';
  import {formatDate} from 'utils'
  export default {
    methods: {
      tableRowClassName(row, index) {
        if (index === 1) {
          return 'info-row';
        } else if (index === 3) {
          return 'positive-row';
        }
        return '';
      },
      fetchData(){
        this.loading=true;
        getUserList().then((response)=>{
          this.loading=false;
          const data = response.data;
          if(data.code==="0000"){
            this.list=data.users.userArray;
          }else{
            this.$message(data.message);
          }
          console.log(response);
        }).catch((error)=>{
            this.loading=true;
            this.$message({message:error.message,type:"error"});
        });
      },
      formateDate(row, column, cellValue){
        return formatDate(row.last_login);
      }
    },
    data() {
      return {
        list:[],
        loading:false,
        highlight:true
      }
    },
    created(){
      this.fetchData();
    }
  }
</script>