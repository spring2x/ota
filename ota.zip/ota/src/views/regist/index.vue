<template>
  <div class="regist-container" id="regist-container">
      <canvas id="star" width="100%" height="100%"></canvas>
      <el-form autoComplete="off" :model="registForm" :rules="rules" ref="registForm" label-position="left" label-width="80px"
      class="card-box regist-form">
      <h3 class="title">平台注册</h3>
      <el-form-item label="用户名" prop="name">
        <el-input name="name" type="text" v-model="registForm.name" placeholder="用户名"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input name="password" type="password"  v-model="registForm.password" autoComplete="off"
          placeholder="密码格式8-16位数字+字母+特殊字符"></el-input>
      </el-form-item>
      <el-form-item label="确认密码" prop="repeatPassword">
        <el-input name="repeatPassword" type="password"  v-model="registForm.repeatPassword" autoComplete="off"
          placeholder="确认密码密码"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" style="width:100%;" :loading="loading" @click.native.prevent="handleRegist">
          注册
        </el-button>
      </el-form-item>
      <div class="tips">
            <router-link to="/login" class="fr">有账号？立即登录</router-link>
      </div>
    </el-form>
  </div>
</template>

<script>
  import { validatePhone,validatePass } from 'utils/validate';
  require("star"); 
  export default {
    components: {  },
    name: 'regist',
    data() {
      const isPhone = (rule, value, callback) => {
        if (!validatePhone(value)) {
          callback(new Error('请输入正确的合法手机号码'));
        } else {
          callback();
        }
      };
      const isPass = (rule, value, callback) => {
        if (!validatePass(value)) {
          callback(new Error('密码格式8-16位数字+字母+特殊字符'));
        } else {
          callback();
        }
      };
      return {
        "registForm":{
          phone:"",
          password:"",
          repeatPassword:""
        },
        "rules":{
          name:[
            { required: true,min: 2, max: 10, message: '长度在 2 到 10 个字符', trigger: 'blur' }
          ],
          password:[
            { required: true, trigger: 'blur' ,validator:isPass}
          ],
          repeatPassword:[
            { required: true, trigger: 'blur' ,validator:isPass}
          ]
        },
        loading: false,
        codeLoading:false
      }
    },
    methods: {
      handleRegist() {
        this.$refs.registForm.validate(valid => {
          if (valid) {
            this.loading = true;
            console.log(this.registForm)
            this.$store.dispatch('Regist', this.registForm).then((res) => {
              this.loading = false;
              if(res.code==="0000"){
                this.$msgbox({
                  showCancelButton: true,
                  confirmButtonText: '去登录',
                  cancelButtonText: '取消',
                  message:"恭喜您注册成功！是否立即登录",
                  beforeClose: (action, instance, done) => {
                    if(action=="confirm"){
                      done();
                      setTimeout(()=>{
                        this.$router.push({path:"/login"})
                      },500)
                    }else{
                      done();
                      this.$refs["registForm"].resetFields();
                    }
                  }
                });
              }else{
                this.$message({message:res.message,type:"error"});
              }
            }).catch(err => {
              this.$message.error(err);
              this.loading = false;
            });
          } else {
              this.loading = false;
              return false;
          }
        });
      }
    },
    created() {
    },
    mounted(){
      var window_width = $(window).width();
      var window_height = $(window).height();
      $('#star').regAnimation({
          window_width: window_width,
          window_height: window_height,
          window_background: '#fff',
          star_count: '100',
          star_color: '#02c5ff',
          star_depth: '600'
      });
    },
    destroyed() {
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  @import "src/styles/mixin.scss";
  .tips {
    font-size: 14px;
    margin-bottom: 5px;
    color: #333;
  }

  .regist-container {
    @include relative;
    height: 100vh;
    #star{
      position: absolute;
      left: 0;
      right: 0;
    }
    .regist-form {
      position: absolute;
      left: 0;
      right: 0;
      width: 500px;
      padding: 35px 35px 15px 35px;
      margin: 120px auto;
    }
    .title {
      font-size: 26px;
      font-weight: 400;
      color: #607D8B;
      margin: 0px auto 40px auto;
      text-align: center;
      font-weight: bold;
    }
    .code-wrap{
      float:left;
      width: 200px;
    }
    .code-btn{
      width: 120px;
      float: right;;
    }
  }
</style>
