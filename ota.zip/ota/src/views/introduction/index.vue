<template>
  <div class="app-container">
      <el-row type="flex" class="row-bg" justify="center">
        <el-col :span="12">
          <div style="margin:20px auto;">
            <h1>升级平台alpha版本</h1>
            <p>平台支持项：ie9+，其他现代浏览器</p>
          </div>
        </el-col>
      </el-row>
       <div class="img-bg"></div>
  </div>
</template>
<script type="text/javascript">
  import banner from 'assets/banner-bg.jpg';
   export default {
    data() {
      return {
        banner: banner
      }
    }
  }
  
</script>
<style scoped>
  .img-bg{
    background: url(../../assets/banner-bg.jpg) no-repeat;
    height: 400px;
    background-size: cover;
  }
  
</style>
