module.exports = {
    NODE_ENV: '"production"',
    BASE_API: '""',
    APP_ORIGIN: '"https://wallstreetcn.com"'
};
